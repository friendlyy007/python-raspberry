# proyectos-WAPOSAT
se desarrollara con buenas practicas todo en python
